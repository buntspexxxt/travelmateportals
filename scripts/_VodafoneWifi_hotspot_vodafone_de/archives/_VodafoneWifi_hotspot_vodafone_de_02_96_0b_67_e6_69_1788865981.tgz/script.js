var API_ENDPOINT = '/api/v4';

var app = angular.module('wifi', ['ngSanitize', 'ngRoute', 'ngCookies'])
    .config(function($routeProvider, $locationProvider, $httpProvider) {
        $routeProvider.when('/login', {
            templateUrl: '/tpl/hotspot-logins.html',
            controller: 'HotspotLoginsCtrl'
        });
        $routeProvider.when('/account', {
            templateUrl: '/tpl/account.html',
            controller: 'AccountCtrl'
        });
        $routeProvider.when('/spot-admin', {
            templateUrl: '/tpl/spot-admin.html',
            controller: 'SpotAdminCtrl'
        });
        $routeProvider.when('/spot-account', {
            templateUrl: '/tpl/spot-account.html',
            controller: 'SpotAccountCtrl'
        });
        $routeProvider.otherwise({
            redirectTo: '/login'
        });
    });

app.controller('NavCtrl', ['$scope', '$location', '$http', '$rootScope', '$cookies', function($scope, $location, $http, $rootScope, $cookies) {

    $scope.loggedIn = false;
    $scope.modalWindow = null;
    $rootScope.$on('modal', function(ev, data) {
        $scope.modalWindow = data;
    });
    $rootScope.$on('loggedIn', function(ev, data) {
        $scope.loggedIn = true;
    });
    $rootScope.$on('loggedOut', function(ev, data) {
        $scope.logout();
    });
    $scope.logout = function() {
        if (window.localStorage) {
            delete(window.localStorage.cscToken);
            delete(window.localStorage.spotToken);
        } else {
            $cookies.put('cid', '', { expires: new Date(), secure: true });
            $cookies.put('sid', '', { expires: new Date(), secure: true });
        }
        $scope.loggedIn = false;
        $location.path('/');
    };

    $scope.modalOkay = function() {
        if ($scope.modalWindow.accept) $scope.modalWindow.accept();
        $scope.modalWindow = null;
    };
    $scope.modalAbort = function() {
        if ($scope.modalWindow.abort) $scope.modalWindow.abort();
        $scope.modalWindow = null;
    };
    $scope.collapsed = false;
    $scope.navClass = function(page) {
        var currentRoute = $location.path().substring(1) || 'home';
        if (Array.isArray(page)) {
            return (page.indexOf(currentRoute) >= 0) ? 'active' : '';
        }
        return page === currentRoute ? 'active' : '';
    };
    $scope.session = null;
    $http({
        method: 'GET',
        url: API_ENDPOINT + '/session'
    }).success(function(data) {
        $scope.session = data;
    });
}]);

app.controller('HotspotLoginsCtrl', ['$scope', '$http', '$location', '$routeParams', '$window', '$location', '$rootScope', '$cookies', function($scope, $http, $location, $routeParams, $window, $location, $rootScope, $cookies) {
    $scope.error = 0;
    $scope.inflight = false;
    $scope.terms = null;

    const searchParams = new URLSearchParams(window.location.search);
    const codeTest = searchParams.get('code');

    if ((window.localStorage && window.localStorage.cscToken && !window.localStorage.getItem("acceptTerms") && !codeTest) || ($cookies.get('cid') && !window.localStorage.getItem("acceptTerms") && !codeTest)) {
        $location.path('/account');
        return;
    }

    $http({
        method: 'GET',
        url: API_ENDPOINT + '/terms/csc/html'
    }).success(function(data) {
        $scope.terms = data;
    }).error(function(err) {

    });


    $scope.accountAnlegen = function() {
        $window.open('https://kabel.vodafone.de/registrierung', '_blank');
    };

    // OID LOGIN start
    $scope.redirectOID = function() {
        $window.open(`${accountUrl ?? ''}${localUrl ?? ''}`, '_self');
    };

    $scope.handleLoginOID = function(code) {
        const paramOID = {
            authorizationCode: code,
            redirectUri: localUrl,
            // force: window.localStorage.getItem("acceptTerms") === 'true',
        };
        if (window.localStorage.getItem("acceptTerms") === 'true') {
            paramOID.force = window.localStorage.getItem("acceptTerms") === 'true';
        }

        $http({
            method: 'POST',
            url: API_ENDPOINT + '/c/csc/session',
            data: paramOID,
        }).success(function(data) {
            if (window.localStorage) {
                window.localStorage.cscToken = data.token;
                window.localStorage.cscValidUntil = data.expires;
            } else {
                $cookies.put('cid', data.token, { expires: new Date(data.expires), secure: true });
            }
            localStorage.removeItem("acceptTerms");

            $location.path('/account');

        }).error(function(err, status) {
            $scope.inflight = false;

            if ((err?.errorCode === 10 || err?.errorCode === 11) && err?.success === false && status == 403) {
                $rootScope.$broadcast('modal', {
                    title: 'Nutzungsdbedingungen bestätigen',
                    body: $scope.terms,
                    acceptText: 'Ich stimme zu',
                    abortText: 'Ich stimme nicht zu',
                    accept: function() {
                        window.localStorage.setItem("acceptTerms", 'true');
                        $scope.redirectOID();
                    },
                    abort: function() {
                        window.localStorage.setItem("acceptTerms", 'false');
                    }
                });

                return;
            }

            switch (status) {
                case 401:
                    $scope.error = 401;
                    break;
                case 403:
                    $scope.error = 403;
                    break;
                case 406:
                    $scope.error = 406;
                    break;
                case 500:
                    $scope.error = 500;
                    break;
                case 503:
                    $scope.error = 503;
                    break;
                default:
                    $scope.error = 500;
                    break;
            }

            localStorage.removeItem("acceptTerms");
        });
    }

    $scope.checkLoginOID = function() {
        const searchParams = new URLSearchParams(window.location.search);
        const code = searchParams.get('code');
        if (code) {
            $scope.handleLoginOID(code);
        }
    };
    $scope.checkLoginOID();
    // OID LOGIN end
}]);

app.controller('AccountCtrl', ['$scope', '$http', '$location', '$routeParams', '$window', '$timeout', '$rootScope', '$cookies', function($scope, $http, $location, $routeParams, $window, $timeout, $rootScope, $cookies) {
    const searchParams = new URLSearchParams(window.location.search);
    const codeTest = searchParams.get('code');
    if (codeTest !== null) {
        const url = window.location;
        const urlObj = new URL(url);
        urlObj.search = '';
        urlObj.href = `${localUrl}#/account`;
        window.location = urlObj.toString();
        return;
    }

    if (window.localStorage && window.localStorage.cscToken) {
        $scope.cscToken = window.localStorage.cscToken;
    } else if ($cookies.get('cid')) {
        $scope.cscToken = $cookies.get('cid');
    }

    if (!$scope.cscToken) {
        return $location.path('/');
    }

    $scope.newAccount = {};
    $scope.wifiAccount = {};

    $scope.errorCreate = 0;
    $scope.errorPassword = 0;

    $scope.macResetAccount = null;
    $scope.preDeleteAccount = null;
    $scope.preChangePassAccount = null;
    $rootScope.$broadcast('loggedIn');
    $scope.terms = null;

    $http({
        method: 'GET',
        url: API_ENDPOINT + '/terms/csc/html'
    }).success(function(data) {
        $scope.terms = data;
    }).error(function(err) {

    });

    $scope.showTerms = function() {
        $rootScope.$broadcast('modal', {
            title: 'Nutzungsbedingungen',
            body: $scope.terms,
            acceptText: 'Schließen'
        });
    };

    $scope.reloadAccounts = function() {
        $http({
            method: 'GET',
            url: API_ENDPOINT + '/c/csc/accounts',
            headers: {
                'X-CSession-Token': $scope.cscToken
            }
        }).success(function(accounts) {
            $scope.accounts = accounts;
            accounts.forEach(function(account) {
                if (!account.lastChange) return;
                var date = new Date(account.lastChange);
                var day = date.getDate();
                if (day < 10) {
                    day = '0' + day;
                }
                var month = date.getMonth() + 1;
                if (month < 10) {
                    month = '0' + month;
                }
                var year = date.getFullYear();
                account.lastChangeString = day + '.' + month + '.' + year;
            });
        }).error(function(err, code) {
            // TODO: Fehler anzeigen
            if (code == 403) {
                $rootScope.$broadcast('loggedOut');
                $location.path('/login');
            }
        });
    };
    $scope.reloadAccounts(); // Trigger directly

    $scope.createAccount = function() {
        // TODO: CHECKS / Länge....
        $http({
            method: 'POST',
            url: API_ENDPOINT + '/c/csc/accounts',
            headers: {
                'Content-Type': 'application/json',
                'X-CSession-Token': $scope.cscToken
            },
            data: $scope.newAccount
        }).success(function(data) {
            $scope.newAccount = {}; // Reset state
            if (data.success) {
                $scope.reloadAccounts();
            }
        }).error(function(err) {
            // TODO: Warnung anzeigen / AGB anzeigen
           if (err.code) {
                $scope.error = err.code;
            } else {
                $scope.error = 500;
            }
            console.log(err);
        });
    };

    $scope.resetMac = function(account) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/c/csc/accounts/' + account.username,
            data: {
                accountType: account.accountType,
                mac: 'null'
            },
            headers: {
                'Content-Type': 'application/json',
                'X-CSession-Token': $scope.cscToken
            }
        }).success(function(data) {
            $scope.reloadAccounts();
            $scope.macResetAccount = null;
        }).error(function(err) {
            $scope.reloadAccounts();
            $scope.macResetAccount = null;
        });
    };

    $scope.deleteAccount = function(account) {
        $http({
            method: 'DELETE',
            url: API_ENDPOINT + '/c/csc/accounts/' + account.username,
            headers: {
                'X-CSession-Token': $scope.cscToken
            }
        }).success(function(data) {
            $scope.reloadAccounts();
            $scope.preDeleteAccount = null;
        }).error(function(err) {
            $scope.reloadAccounts();
            $scope.preDeleteAccount = null;
        });
    };

    // Debounce
    var chTimer;
    $scope.$watch('newAccount.username', function() {
        if (chTimer) $timeout.cancel(chTimer);
        chTimer = $timeout(function() {
            $scope.checkUsername($scope.newAccount.username);
        }, 500);
    });

    $scope.hidePassTable = function() {
        $scope.preChangePassAccount = null;
    };

    $scope.changePass = function(account) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/c/csc/accounts/' + account.username,
            data: {
                accountType: account.accountType,
                password: account.newPassword
            },
            headers: {
                'X-CSession-Token': $scope.cscToken,
                'Content-Type': 'application/json'
            }
        }).success(function(data) {
            $scope.reloadAccounts();
            $scope.preChangePassAccount = null;
        }).error(function(data) {
            $scope.reloadAccounts();
            $scope.preChangePassAccount = null;
        });
    };

    $scope.enableAccount = function(account, enable) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/c/csc/accounts/' + account.username,
            dataType: 'json',
            data: {
                active: enable,
                accountType: account.accountType,
                username: account.username
            },
            headers: {
                'X-CSession-Token': $scope.cscToken,
                'Content-Type': 'application/json'
            }
        }).success(function(data) {
            $scope.reloadAccounts();
        }).error(function(data) {});
    };

    $scope.checkUsername = function(username) {
        if (!username) {
            $scope.errorCreate = 0;
            return;
        }
        $http({
            method: 'GET',
            url: API_ENDPOINT + '/c/csc/accounts/' + username,
            headers: {
                'X-CSession-Token': $scope.cscToken
            }
        }).success(function(data) {
            $scope.errorCreate = 10;
        }).error(function(err, code) {
            if (code == 423) {
                $scope.errorCreate = 10;
                return;
            }
            $scope.errorCreate = 0;
        });
    };

    $scope.checkInvalidChars = function(str) {
        return (/^[a-z0-9_\-.,]*$/i).test(str);
    };

    $scope.checkPassword = function(password) {
        if (!password) {
            $scope.errorPassword = 0;
            return;
        }
        if (password.length < 8 || password.length > 20) {
            $scope.errorPassword = 11;
        } else {
            $scope.errorPassword = 0;
        }
    };

    $scope.checkPassword2 = function(account) {
        if (!account.newPassword) {
            account.passwordFail = false;
            return;
        }
        if (account.newPassword.length < 8 || account.newPassword.length > 20) {
            account.passwordFail = true;
            return;
        } else {
            account.passwordFail = false;
            return;
        }
    };

    $scope.checkPreconditions = function() {
        if ($scope.errorCreate || $scope.errorPassword || !$scope.newAccount.username || !$scope.newAccount.password || !$scope.newAccount.acceptTerms) return false;
        return true;
    };

    $scope.resetMacPre = function(account) {
        $scope.macResetAccount = account;
    };

    $scope.abortResetMac = function() {
        $scope.macResetAccount = null;
    };

    $scope.deleteAccountPre = function(account) {
        $scope.preDeleteAccount = account;
    };

    $scope.changePassPre = function(account) {
        $scope.preChangePassAccount = account;
    };

    $scope.abortDeleteAccount = function() {
        $scope.preDeleteAccount = null;
    };
}]);

app.controller('SpotAdminCtrl', ['$scope', '$http', '$location', '$routeParams', '$window', '$cookies', function($scope, $http, $location, $routeParams, $window, $cookies) {
    $scope.error = 0;
    $scope.inflight = false;
    $scope.noSpot = false;

    $scope.spotLogin = function(username, password) {
        $scope.inflight = true;
        $http({
            method: 'POST',
            url: API_ENDPOINT + '/spotAdmin/session',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                username: username,
                password: password,
                scope: 'spot-admin'
            }
        }).success(function(data) {
            $http({
                method: 'GET',
                url: API_ENDPOINT + '/spotAdmin',
                headers: {
                    'X-CSession-Token': data.token
                }
            }).success(function(data2) {
                $scope.inflight = false;
                $scope.hotspotCount = data2.length;
                if ($scope.hotspotCount == 0) {
                    $scope.noSpot = true;
                    return;
                }
                if (window.localStorage) {
                    window.localStorage.spotToken = data.token;
                    window.localStorage.spotValidUntil = data.expires;
                } else {
                    $cookies.put('sid', data.token, { expires: new Date(data.expires), secure: true });
                }
                $location.path('/spot-account');
            }).error(function(err) {
                $scope.inflight = false;
                // Es kommt fehler hier
            });
        }).error(function(err) {
            console.log(err)
            $scope.inflight = false;
            if (err.code) {
                $scope.error = err.code;
            } else {
                $scope.error = 403;
            }
        });
    };

    $scope.pdfDownload = function() {
        $window.open('static/WLAN-hotspot_empfehlen_und_Praemie_erhalten.pdf', '_blank');
    };

    $scope.accountAnlegen = function() {
        $window.open('https://kabel.vodafone.de/registrierung', '_blank');
    };
}]);

app.controller('SpotAccountCtrl', ['$scope', '$http', '$location', '$routeParams', '$window', '$rootScope', '$cookies', function($scope, $http, $location, $routeParams, $window, $rootScope, $cookies) {
    $scope.infoSuccess = false;

    if (window.localStorage && window.localStorage.spotToken) {
        $scope.spotToken = window.localStorage.spotToken;
    } else if ($cookies.get('sid')) {
        $scope.spotToken = $cookies.get('sid');
    }

    if (!$scope.spotToken) {
        return $location.path('/');
    }

    $rootScope.$broadcast('loggedIn');

    $scope.reloadSpots = function() {
        $http({
            method: 'GET',
            url: API_ENDPOINT + '/spotAdmin',
            headers: {
                'X-CSession-Token': $scope.spotToken
            }
        }).success(function(data) {
            $scope.hotspots = data;
            data.forEach(function(spot) {
                spot.imgUrl = '/api/v4/spotAdmin/image?x-csession-token=' + $scope.spotToken + '&successurl=' + encodeURIComponent('/service/#/spot-account') + '&failurl=' + encodeURIComponent('/service/#/spot-account/error');
            });
        }).error(function(err, code) {
            if (code == 403) {
                $rootScope.$broadcast('loggedOut');
                $location.path('/spot-admin');
            }
        });
    };
    $scope.reloadSpots();

    $scope.deleteLogo = function(id) {
        $http({
            method: 'DELETE',
            url: API_ENDPOINT + '/spotAdmin/image',
            headers: {
                'X-CSession-Token': $scope.spotToken
            }
        }).success(function() {
            $scope.reloadSpots();
        }).error(function(err) {
            // Fehler Meldung
        });
    };

    $scope.deleteName = function(id) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/spotAdmin/ap/' + id + '/attribs',
            dataType: 'json',
            data: {
                name: null,
                field: "name"
            },
            headers: {
                'X-CSession-Token': $scope.spotToken,
                'Content-Type': 'application/json'
            }
        }).success(function() {
            $scope.reloadSpots();
        }).error(function(err) {
            //Fehler Meldung
        });
    };

    $scope.changeName = function(spot) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/spotAdmin/ap/' + spot.id + '/attribs',
            dataType: 'json',
            data: {
                name: spot.newName,
                field: "name" 
            },
            headers: {
                'X-CSession-Token': $scope.spotToken,
                'Content-Type': 'application/json'
            }
        }).success(function() {
            spot.name = spot.newName;
            spot.newName = '';
            $scope.infoSuccess = true;
            // return $location.path('/spot-account');
        }).error(function(err) {
            //Fehler Meldung
        });
    };

    $scope.deleteUrl = function(id) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/SpotAdmin/ap/' + id + '/attribs',
            data: {
                url: null,
                field: "url"
            },
            headers: {
                'X-CSession-Token': $scope.spotToken,
                'Content-Type': 'application/json'
            }
        }).success(function() {
            $scope.reloadSpots();
        }).error(function(err) {
            //Fehler Meldung
        });
    };

    $scope.saveUrl = function(spot) {
        $http({
            method: 'PUT',
            url: API_ENDPOINT + '/spotAdmin/ap/' + spot.id +'/attribs' ,
            data: {
                url: spot.newUrl,
                field: "url"
            },
            headers: {
                'X-CSession-Token': $scope.spotToken,
                'Content-Type': 'application/json'
            }
        }).success(function() {
            spot.url = spot.newUrl;
            spot.newUrl = null;
            $scope.infoSuccess = true;
        }).error(function(err) {
            //Fehler Meldung
        });
    };
}]);
