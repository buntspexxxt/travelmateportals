(function ($) {
    let closeSelects = function () {
        $('.js-select').removeClass('is-in');
    }

    let toggleSelect = function ($target) {
        if ($target.parents('.js-select').hasClass('is-in')) {
            closeSelects();
        } else {
            closeSelects();

            $target.parents('.js-select').addClass('is-in');
        }
    }

    $('.js-select .m-select__current').on('click', function () {
        toggleSelect($(this));
    });

    $('.js-select .m-select__menue a').on('click', function () {
        closeSelects();
    });

    $(document).keyup(function (e) {
        if (e.keyCode === 27) {
            closeSelects();
        }
    });

    $(document).mouseup(function (e) {
        let container = $('.js-select');

        if (!container.is(e.target) && container.has(e.target).length === 0) {
            closeSelects();
        }
    });
})(jQuery);

$('.js-scoll-to-nutzungsbedingungen').on('click', function () {
    $('html, body').animate({
        scrollTop: $('#scroll-to-nutzungsbedingungen').offset().top
    }, 300, function () {
        $('#nutzungsbedingungen').collapse('show');
    });
});

let accordion = $('.m-accordion');

accordion.on('show.bs.collapse', function (event) {
    $(event.target).parents('.m-accordion__element').find('.m-accordion__headline').addClass('is-active');
});

accordion.on('hide.bs.collapse', function (event) {
    $(event.target).parents('.m-accordion__element').find('.m-accordion__headline').removeClass('is-active');
});

(function () {
    let forms = document.getElementsByClassName('needs-validation');
    Array.prototype.filter.call(forms, function (form) {
        form.addEventListener('submit', function (event) {
            if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    }, false);
})();