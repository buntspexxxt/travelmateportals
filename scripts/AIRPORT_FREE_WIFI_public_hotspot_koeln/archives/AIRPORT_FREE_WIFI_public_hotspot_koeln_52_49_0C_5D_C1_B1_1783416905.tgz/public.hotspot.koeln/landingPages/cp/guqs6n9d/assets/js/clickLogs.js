$(document).click(function (e) {
    processLogging($(e.target));
});

document.onreadystatechange = function () {
    if (document.readyState === 'complete') {
        let body = $('body');

        sendClickLog({
            'action': 'load',
            'itemType': $(body).data('item-type') ? $(body).data('item-type') : 'unknown',
            'itemValue': $(body).data('item-value') ? $(body).data('item-value') : 'unknown'
        });
    }
};

function processLogging(clickObj) {
    var sendData = {};
    var objInfo = {
        clickObject: clickObj,
        lvl: 6
    };

    if (!clickObj.data('item-type') && !clickObj.data('item-value')) {
        objInfo = findDataObject(objInfo, null);
        clickObj = (objInfo.clickObject ? objInfo.clickObject : clickObj);
    }

    if (clickObj.prop('tagName') === 'BODY') {
        return false;
    }

    if (clickObj.data('item-type') && clickObj.data('item-value')) {
        sendData.itemType = clickObj.data('item-type');
        sendData.itemValue = clickObj.data('item-value');
        sendData.itemAdditional = clickObj.data('item-additional');

        sendClickLog(sendData);
    } else if (clickObj.data('item-type') && !clickObj.data('item-value')) {
        sendData.itemType = clickObj.data('item-type');
        sendData.itemAdditional = clickObj.data('item-additional');

        sendClickLog(sendData);
    } else if (!clickObj.data('item-type') && clickObj.data('item-value')) {
        sendData.itemValue = clickObj.data('item-value');

        objInfo.clickObject = clickObj;
        objInfo = findDataObject(objInfo, 'item-type');

        clickObj = (objInfo.clickObject ? objInfo.clickObject : clickObj);

        if (clickObj.data('item-type')) {
            sendData.itemType = clickObj.data('item-type');
        }

        if (clickObj.prop('tagName') === 'BODY') {
            return false;
        }

        sendData.itemAdditional = clickObj.data('item-additional');

        sendClickLog(sendData);
    }
}

function findDataObject(objInfo, search) {
    let obj = {};
    let level = objInfo.lvl;
    let tagObject = objInfo.clickObject;

    if (search === null && (tagObject.data('item-type') || tagObject.data('item-value'))) {
        obj.clickObject = tagObject;
        obj.lvl = level;
        return obj;
    } else if (search !== null && tagObject.data(search)) {
        obj.clickObject = tagObject;
        obj.lvl = level;
        return obj;
    } else if (level <= 0) {
        obj.clickObject = null;
        obj.lvl = null;
        return obj;
    }

    if (tagObject.parent()) {
        obj.clickObject = tagObject.parent();
        obj.lvl = level - 1;
        objInfo = findDataObject(obj, search);
    }

    return objInfo;
}

function sendClickLog(data) {
    let url = $('body').data('click-logs');

    if (typeof url !== 'string' || url.length < 1) {
        return;
    }

    $.ajax({
        url: url,
        method: 'POST',
        data: data
    });
}