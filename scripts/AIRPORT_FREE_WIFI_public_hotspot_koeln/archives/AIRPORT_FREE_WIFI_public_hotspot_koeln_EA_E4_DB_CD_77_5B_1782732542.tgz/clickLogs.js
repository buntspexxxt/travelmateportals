<!DOCTYPE HTML>
<html lang="de">
<head>
    <title>hotspot.koeln</title>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="msapplication-TileColor" content="#ffffff"/>
    <meta name="theme-color" content="#ffffff"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="/landingPages/cp/guqs6n9d/assets/css/main.css"/>
        <link rel="apple-touch-icon" href="/landingPages/cp/guqs6n9d/assets/img/favicon/apple-touch-icon.png" sizes="180x180"/>
    <link rel="icon" type="image/png" href="/landingPages/cp/guqs6n9d/assets/img/favicon/favicon-32x32.png" sizes="32x32"/>
    <link rel="icon" type="image/png" href="/landingPages/cp/guqs6n9d/assets/img/favicon/favicon-16x16.png" sizes="16x16"/>
    <link rel="mask-icon" href="/landingPages/cp/guqs6n9d/assets/img/favicon/safari-pinned-tab.svg" color="#5bbad5"/>
    <link rel="shortcut icon" href="/landingPages/cp/guqs6n9d/assets/img/favicon/favicon.ico"/>
    <script src="/landingPages/cp/guqs6n9d/assets/vendor/jquery-3.7.1/jquery-3.7.1.min.js"></script>
    <script src="/landingPages/cp/guqs6n9d/assets/vendor/bootstrap-4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="/landingPages/cp/guqs6n9d/assets/js/main.js" defer="defer"></script>
            <script src="/landingPages/cp/guqs6n9d/assets/js/clickLogs.js"></script>
    </head>
<body class="with-connect" data-item-type="landing_page" data-item-value="start" data-click-logs="/clickLogs/cp/guqs6n9d">
<div class="m-page">
    <div class="m-header">
        <div class="m-header__inner-container">
            <div class="m-select js-select">
                <button class="m-select__current">DE</button>
                <div class="m-select__menue">
                    <ul>
                                                    <li class="is-active">
                                <a href="?locale=de_DE" data-item-type="landing_page" data-item-value="german" data-item-additional="start" class="german"><span>DE</span></a>
                            </li>
                                                    <li>
                                <a href="?locale=en_GB" data-item-type="landing_page" data-item-value="english" data-item-additional="start" class="english"><span>EN</span></a>
                            </li>
                                                    <li>
                                <a href="?locale=uk_UA" data-item-type="landing_page" data-item-value="ukrainian" data-item-additional="start" class="ukrainian"><span>UK</span></a>
                            </li>
                                                    <li>
                                <a href="?locale=ru_RU" data-item-type="landing_page" data-item-value="russian" data-item-additional="start" class="russian"><span>RU</span></a>
                            </li>
                                                    <li>
                                <a href="?locale=nl_NL" data-item-type="landing_page" data-item-value="nederlands" data-item-additional="start" class="nederlands"><span>NL</span></a>
                            </li>
                                                    <li>
                                <a href="?locale=tr_TR" data-item-type="landing_page" data-item-value="turkey" data-item-additional="start" class="turkey"><span>TR</span></a>
                            </li>
                                            </ul>
                </div>
            </div>
        </div>
    </div>
        <div class="m-main">
                            <img src="/landingPages/cp/guqs6n9d/assets/data/uex6kk1meea5qzj6.jpg" alt="Logo"/>
                <div class="m-text">
                                                                <p>
                        Gestalten Sie mit uns die Zukunft des Parkens: Nehmen Sie jetzt an unserer kurzen Umfrage teil.
                    </p>
                                    </div>
        <form class="needs-validation custom-checkbox-error-form" novalidate action="/login" method="post">
            <div class="form-group">
                <div class="custom-control custom-checkbox mb-3">
                    <input type="checkbox" class="custom-control-input" id="customControlValidation1" required/>
                    <div class="invalid-feedback custom-checkbox-error">Bitte akzeptiere die Nutzungsbedingungen</div>
                    <label class="custom-control-label" for="customControlValidation1">
                        Ich stimme den <a href="#" class="js-scoll-to-nutzungsbedingungen">Nutzungsbedingungen</a> zu
                    </label>
                </div>
            </div>
                                    <input type="hidden" name="login" value="oneclick"/>
            <button type="submit" class="major fixed-width" data-item-type="landing_page" data-item-value="connect" data-item-additional="oneclick">Jetzt lossurfen</button>
            
        </form>
        <div class="m-accordion">
            <div class="m-accordion__element" id="scroll-to-nutzungsbedingungen">
                <a href="#nutzungsbedingungen" class="m-accordion__headline" data-toggle="collapse">Nutzungsbedingungen</a>
                <div class="m-accordion__collapse collapse" id="nutzungsbedingungen">
                    <div class="m-accordion__content">
                        <div class="m-text">
                            <h4>§1 Vertragspartner</h4>

<p>Vertragspartner sind die NetCologne GmbH (im Weiteren als Betreiber bezeichnet) und der Nutzer.</p>

<h4>§2 Gegenstand der Bedingungen</h4>
<p>Die nachfolgenden Bedingungen regeln in Verbindung mit dem Telekommunikationsgesetz (TKG) die Inanspruchnahme des öffentlichen WLAN-Hotspot-Netzwerks des Betreibers durch den jeweiligen Nutzer. Durch die Benutzung des jeweiligen WLAN-Hotspots wird dem Nutzer der kabellose Zugang zum weltweiten Internet ermöglicht. Die Nutzung dieser Leistung kann – in Abhängigkeit vom Standort des WLAN-Hotspots – entweder über das sogenannte One-Klick-Verfahren und / oder über einen Voucher mit Zugangsdaten erfolgen, welcher dem jeweiligen Nutzer (bspw. Personen unter 25 Jahren, Flüchtlinge oder Neukunden der NetCologne.) vom Betreiber oder einem autorisierten Partner ausgehändigt wurde.</p>

<h4>§2.1 Zustandekommen des Vertrags</h4>
<p>Der Vertrag zwischen dem Betreiber und dem Nutzer kommt mit der Zustimmung zu den Nutzungsbedingungen durch den Nutzer zustande.</p>

<h4>§3 Leistungen des Betreibers</h4>
<p>Der Betreiber erbringt im Rahmen der bestehenden technischen und betrieblichen Möglichkeiten folgende Leistungen:</p>

<h4>§3.1 Internetzugang</h4>
<p>Der Betreiber ermöglicht dem Nutzer einen zeitlich befristeten öffentlichen WLAN-Zugang zum Internet. Der Nutzer erkennt an, dass keine bestimmte Übertragungsgeschwindigkeit garantiert werden kann. Diese ist u.a. von der Wahl der Zugangsvariante, von technischen Erfordernissen und von der Anzahl der Nutzer am jeweiligen WLAN-Hotspot-Standort abhängig.</p>
<p>Der Betreiber bietet die Nutzung des Internetzugangs im Rahmen des üblichen Nutzungsverhaltens an. Abhängig von Standort und der Zugangsvariante kann es zu unterschiedlichen Leistungsmerkmalen (z.B. der zur Verfügung stehende Bandbreite) kommen.</p>
<p>Die Dauer der Nutzung ist bei Nutzung des OneClick-Verfahrens grundsätzlich auf vier Stunden ab dem jeweiligen Login limitiert (wiederholter Login möglich). Bei der Nutzung eines Vouchers ist die Nutzungsdauer entsprechend der Angaben auf dem Voucher zeitlich limitiert.</p>
<p>Eine Verpflichtung des Betreibers, dem Nutzer einen öffentlichen Zugang zum Internet zur Verfügung zu stellen, besteht nicht. Eine jederzeitige und ununterbrochen störungsfreie Zurverfügungstellung oder eine bestimmte Internetgeschwindigkeit wird nicht gewährleistet. Die Nutzung kann durch geografische, atmosphärische oder sonstige Bedingungen (bspw. Abschattung) oder Umstände, die außerhalb der Kontrolle des Betreibers liegen, beeinträchtigt werden. Eine Verpflichtung des Betreibers zur Gewährung des Zugangs am jeweiligen WLAN-Hotspot-Standort besteht nicht.</p>
<p>Der Betreiber behält sich das Recht vor, den Zugang zum WLAN-Hotspot oder einzelne Zugangsstandorte ohne vorherige Ankündigung zu ändern, zu beschränken oder einzustellen (bspw. im Falle notwendiger technischer Reparatur- und Wartungsarbeiten oder aus rechtlichen, politischen Gründen, etc.).</p>

<h4>§3.2 Technische Nutzungsvoraussetzungen</h4>
<p>Zur Nutzung des kabellosen Zugangs zum Internet ist ein WLAN-fähiges Endgerät notwendig. Dabei ist darauf zu achten, dass die WLAN-Schnittstelle als DHCP-Client konfiguriert ist. Die Schaffung dieser Nutzungsvoraussetzungen obliegt alleinig dem Nutzer.</p>
<p>Die Nutzung des öffentlichen WLANs kann über Eingabe der Zugangsdaten des Vouchers bestehend aus Benutzername und Passwort oder auch über das sogenannte One-Click-Verfahren erfolgen.</p>

<h4>§4 Haftungsausschluss</h4>
<p>Die Bereitstellung des WLAN-Hotspot-Netzwerks erfolgt ohne zusätzliche Kosten für den Nutzer als Gefälligkeit. Der Betreiber haftet nicht für Schäden, die durch die Benutzung des Hotspots entstehen können. Der Nutzer ist selbst dafür verantwortlich sicherzustellen, dass alle von ihm im Zusammenhang mit dem öffentlichen WLAN genutzten Einrichtungen ausreichend gegen Bedrohungen und Datenzugriffe Dritter, wie z.B. Viren, Würmer und trojanische Pferde, z.B. durch Virenscanner, Firewall o.ä. gesichert sind.</p>
<p>Die Datenübertragung innerhalb des WLAN-Hotspot-Netzwerks zum Internet erfolgt unverschlüsselt. Für zusätzliche Sicherheit bspw. bei der Übertragung von sensiblen Daten hat der Nutzer selbst Sorge zu tragen.</p>
<p>Die Haftung nach zwingenden gesetzlichen Regelungen bleibt hiervon unberührt.</p>

<h4>§5 Pflichten des Nutzers</h4>

<p>Eine missbräuchliche Nutzung des Hotspots ist untersagt, insbesondere</p>
<ul>
<li>die Verbreitung von rechts- oder sittenwidrigen Inhalten;</li>
<li>die Nutzung von Peer-to-Peer Netzwerken;</li>
<li>der Versuch des Eindringens in fremde Datennetze;</li>
<li>der unaufgeforderte Nachrichtenversand (Spamming);</li>
<li>die Beeinträchtigung oder der unerlaubte Zugang / Zugangsversuch zum Nutzer-Account eines anderen WLAN-Hotspot-Nutzers;</li>
<li>der Versand von Dateien oder Dateianhängen mit Schadsoftware (bspw. Viren, etc);</li>
<li>die Übertragung überdurchschnittlich großer Datenmengen und insbesondere die anhaltende Übertragung solcher Datenmengen sind nicht zulässig;</li>
<li>das Benutzen oder die Anwendung von Einrichtungen, die zu Störungen / Veränderungen an der physikalischen oder logischen Struktur der WLAN-Hotspot-Server, des WLAN-Hotspot-Netzes oder anderer Telekommunikationsnetze führen oder führen können. Bei schuldhafter Pflichtverletzung haftet der Nutzer gegenüber dem Betreiber auf Schadenersatz;</li>
<li>ist der Nutzer verpflichtet, bei Zugriff auf Inhalte oder Software, die Eigentum Dritter sind bzw. in Lizenz von Dritten überlassen werden und welche die Erfüllung bestimmter Nutzungsbedingungen fordern, diese Bedingungen zu erfüllen.</li>
</ul>
<p>Der Betreiber behält sich das Recht vor, den Zugang zum WLAN-Hotspot-Netzwerk zu sperren, wenn der Nutzer die ihm obliegende Pflichten verletzt.</p>

<h4>§6 Verantwortlichkeit für den Inhalt der Internetabrufe</h4>
<p>Der Nutzer ist für die Inhalte, die er über den Hotspot aus dem Internet abruft oder bereitstellt, selbst verantwortlich. Der Betreiber nimmt sich jedoch das Recht, den Abruf von rechts- oder sittenwidrigen Inhalten zu blockieren.</p>
<p>Der Nutzer stellt den Betreiber und ihre Erfüllungsgehilfen von sämtlichen Ansprüchen Dritter frei, die auf einer diesen Nutzungsbedingungen WLAN-Hotspot widersprechenden oder sonst wie rechtswidrigen Verwendung des WLAN-Hotspot-Netzwerks und der hiermit verbundenen Leistungen durch den Nutzer beruhen oder mit seiner Billigung erfolgen oder, die sich insbesondere aus datenschutzrechtlichen, urheberrechtlichen oder sonstigen rechtlichen Streitigkeiten ergeben, die mit der Nutzung eines WLAN-Hotspots durch den Nutzer verbunden sind. Erkennt der Nutzer oder muss er erkennen, dass ein solcher Verstoß droht oder stattgefunden hat, hat er die Pflicht, den Betreiber unverzüglich hierüber zu unterrichten.</p>

<h4>§7 Nutzung durch Dritte</h4>
<p>Der Betreiber ermöglicht dem Nutzer mit den Zugangsdaten eines persönlich ausgehändigten Voucher zeitlich befristet ein Endgerät automatisch mit dem WLAN-Hotspot-Netzwerk zu verbinden. Diese Nutzung ist auf die Zielgruppe der jeweiligen Marketingaktion beschränkt, bspw. Personen unter 25 Jahren, Flüchtlinge, Neukunden. Dem Nutzer ist es nicht gestattet, die Zugangsdaten seines Vouchers an Dritte weiterzugeben. Der Nutzer hat die Kosten zu tragen und ist für sämtliche Ansprüche Dritter verantwortlich, die durch unbefugte Nutzung des WLAN-Hotspot-Netzwerks durch Dritte entstanden sind, wenn und soweit der Nutzer diese Nutzung zu vertreten hat.</p>

<h4>§8 Preise und Tarife</h4>
<p>Die Nutzung des WLAN-Hotspot-Netzwerks am jeweiligen Standort ist kostenlos.</p>

<h4>§9 Sonstiges</h4>
<p>Es bestehen keine mündlichen Nebenabreden. Für die vertraglichen Beziehungen der Vertragspartner gilt deutsches Recht.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="m-accordion__element">
                <a href="#impressum" class="m-accordion__headline" data-toggle="collapse">Impressum</a>
                <div class="m-accordion__collapse collapse" id="impressum">
                    <div class="m-accordion__content">
                        <div class="m-text">
                            <h4>NetCologne Gesellschaft für Telekommunikation mbH</h4><p><b>Sitz:</b> Am Coloneum 9, 50829 Köln<br><b>Telefon:</b> 0221 2222-0<br><b>ServiceLine:</b> 0221 2222-800<br><b>Fax:</b> 0221 2222-390<br><b>Web:</b> www.netcologne.koeln<br><b>E-Mail:</b> info@netcologne.de</p><p><b>Geschäftsführung:</b> Timo von Lepel, Dr. Claus van der Velden<br><b>Vorsitzender des Aufsichtsrates:</b> Andreas Feicht<br><b>Handelsregister:</b> Amtsgericht Köln HRB 25580<br><b>Ust-IDNr.:</b> DE 811808435<br><b>Bankverbindung:</b> Sparkasse KölnBonn | Konto-Nr. 2462950 | BLZ 370 501 98 | IBAN DE11370501980002462950 | BIC COLSDE33</p><p><b>Aufsichtsbehörde:</b> Bundesnetzagentur für Elektrizität, Gas, Telekommunikation, Post und Eisenbahnen, Tulpenfeld 4, 53113 Bonn<br><b>Online-Streitbeilegung:</b> http://ec.europa.eu/consumers/odr/</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="m-accordion__element">
                <a href="#datenschutz" class="m-accordion__headline" data-toggle="collapse">Datenschutz</a>
                <div class="m-accordion__collapse collapse" id="datenschutz">
                    <div class="m-accordion__content">
                        <div class="m-text">
                            <h2>1. Datenschutz auf einen Blick</h2><h3>Allgemeine Hinweise</h3><p>Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit ihren personenbezogenen Daten passiert, wenn Sie unsere Webseite besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können. Ausführliche Informationen zum Thema Datenschutz entnehmen Sie unserer unter diesem Text aufgeführten Datenschutzerklärung</p><h3>Datenerfassung auf unserer Webseite</h3><h4>Wer ist verantwortlich für die Datenerfassung auf dieser Webseite?</h4><p>Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten können Sie dem Impressum dieser Website entnehmen.</p><h4>Wie erfassen wir Ihre Daten?</h4><p>Ihre Daten werden zum einen dadurch erhoben, dass Sie uns diese mitteilen. Hierbei kann es sich z.B. um Daten handeln, die Sie in ein Kontaktformular eingeben.</p><p>Andere Daten werden automatisch beim Besuch der Website durch unsere IT-Systeme erfasst. Das sind vor allem technische Daten (z.B. Internetbrowser, Betriebssystem oder Uhrzeit des Seitenaufrufs). Die Erfassung dieser Daten erfolgt automatisch, sobald Sie unsere Webseite betreten.</p><h4>Wofür nutzen wie Ihre Daten?</h4><p>Ein Teil der Daten wird erhoben, um eine fehlerfreie Bereitstellung der Website zu gewährleisten. Andere Daten können zur Analyse Ihres Nutzerverhaltens verwendet werden.</p><h4>Welche Rechte haben Sie bezüglich Ihrer Daten?</h4><p>Sie haben jederzeit das Recht unentgeltlich Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten personenbezogenen Daten zu erhalten. Sie haben außerdem ein Recht, die Berichtigung, Sperrung oder Löschung dieser Daten zu verlangen. Hierzu sowie zu weiteren Fragen zum Thema Datenschutz können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden. Des Weiteren steht Ihnen ein Beschwerderecht bei der zuständigen Aufsichtsbehörde zu.</p><h3>Analyse-Tools und Tools von Drittanbietern</h3><p>Beim Besuch unserer Website kann Ihr Surf-Verhalten statistisch ausgewertet werden. Das geschieht vor allem mit Cookies und mit sogenannten Analyseprogrammen. Die Analyse Ihres Surf-Verhaltens erfolgt in der Regel anonym; das Surf-Verhalten kann nicht zu Ihnen zurückverfolgt werden. Sie können dieser Analyse widersprechen oder sie durch die Nichtbenutzung bestimmter Tools verhindern. Detaillierte Informationen dazu finden Sie in der folgenden Datenschutzerklärung.</p><p>Sie können dieser Analyse widersprechen. Über die Widerspruchsmöglichkeiten werden wie Sie in dieser Datenschutzerklärung informieren.</p><h2>2. Allgemeine Hinweise und Pflichtinformationen Datenschutz</h2><h3>Datenschutz</h3><p>Die Betreiber dieser Seiten nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Wir behandeln Ihre persönlichen Daten vertraulich und entsprechend der gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.</p><p>Wenn Sie diese Website benutzen, werden verschiedene personenbezogene Daten erhoben. Personenbezogene Daten sind Daten mit denen Sie persönlich identifiziert werden können. Die vorliegende Datenschutzerklärung erläutert, welche Daten wir erheben und wofür wir sie nutzen. Sie erläutert auch, wie und zu welchem Zweck das geschieht.</p><p>Wir weisen darauf hin, dass die Datenübertragung im Internet (z.B. bei der Kommunikation per E-Mail) Sicherheitslücken aufweisen kann. Ein lückenloser Schutz der Daten vor dem Zugriff durch Dritte ist nicht möglich.</p><h3>Hinweis zur verantwortlichen Stelle</h3><p>Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist: </p><p>NetCologne Gesellschaft für Telekommunikation mbH<br>Am Coloneum 9<br>50829 Köln<br>Germany</p><p>Datenschutzbeauftragter: Martin Huerkamp</p><p><b>Telefon:</b> 0221 2222-313<br><b>Telefax:</b> 0221 2222-5255<br><b>E-Mail:</b> Datenschutz@netcologne.de</p><p>Verantwortliche Stelle ist die natürliche oder juristische Person, die allein oder gemeinsam mit anderen über die Zwecke und Mittel der Verarbeitung von personenbezogenen Daten (z.B. Namen, E-Mail-Adressen o.Ä.) entscheidet.</p><h3>Wiederruf Ihrer Einwilligung zur Datenverarbeitung</h3><p>Viele Datenverarbeitungsvorgänge sind nur mit Ihrer ausdrücklichen Einwilligung möglich. Sie können eine bereits erteilte Einwilligung jederzeit widerrufen. Dazu reicht eine formlose Mitteilung per E-Mail an uns. Die Rechtmäßigkeit der bis zum Widerruf erfolgten Datenverarbeitung bleibt vom Widerruf unberührt.</p><h3>Beschwerderecht bei der zuständigen Aufsichtsbehörde</h3><p>Im Falle datenschutzrechtlicher Verstöße steht dem Betroffenen ein Beschwerderecht bei der zuständigen Aufsichtsbehörde zu. Zuständige Aufsichtsbehörde in datenschutzrechtlichen Fragen ist der Landesdatenschutzbeauftragte des Bundeslandes, in dem unser Unternehmen seinen Sitz hat. Eine Liste der Datenschutzbeauftragten sowie deren Kontaktdaten können folgendem Link entnommen werden: www.bfdi.bund.de.</p><h3>Recht auf Datenübertragbarkeit</h3><p>Sie haben das Recht, Daten, die wir auf Grundlage Ihrer Einwilligung oder in Erfüllung eines Vertrags automatisiert verarbeiten, an sich oder an einen Dritten in einem gängigen, maschinenlesbaren Format aushändigen zu lassen. Sofern Sie die direkte Übertragung der Daten an einen anderen Verantwortlichen verlangen, erfolgt dies nur, soweit es technisch machbar ist.</p><h3>SSL- bzw. TLS-Verschlüsselung</h3><p>Diese Seite nutzt aus Sicherheitsgründen und zum Schutz der Übertragung vertraulicher Inhalte, wie zum Beispiel Bestellungen oder Anfragen, die Sie an uns als Seitenbetreiber senden, eine SSL- bzw. TLS-Verschlüsselung. Eine verschlüsselte Verbindung erkennen Sie daran, dass die Adresszeile des Browsers von „http://“ auf „https://“ wechselt und an dem Schloss-Symbol in Ihrer Browserzeile.</p><p>Wenn die SSL- bzw. TLS-Verschlüsselung aktiviert ist, können die Daten, die Sie an uns übermitteln, nicht von Dritten mitgelesen werden.</p><h3>Verschlüsselter Zahlungsverkehr auf dieser Website</h3><p>Besteht nach dem Abschluss eines kostenpflichtigen Vertrags eine Verpflichtung, uns Ihre Zahlungsdaten (z.B. Kontonummer bei Einzugsermächtigung) zu übermitteln, werden diese Daten zur Zahlungsabwicklung benötigt.</p><p>Der Zahlungsverkehr über die gängigen Zahlungsmittel (Visa/MasterCard, Lastschriftverfahren) erfolgt ausschließlich über eine verschlüsselte SSL- bzw. TLS-Verbindung. Eine verschlüsselte Verbindung erkennen Sie daran, dass die Adresszeile des Browsers von „http://“ auf „https://“ wechselt und an dem Schloss-Symbol in Ihrer Browserzeile.</p><p>Bei verschlüsselter Kommunikation können Ihre Zahlungsdaten, die Sie an uns übermitteln, nicht von Dritten mitgelesen werden.</p><h3>Auskunft, Sperrung, Löschung</h3><p>Sie haben im Rahmen der geltenden gesetzlichen Bestimmungen jederzeit das Recht auf unentgeltliche Auskunft über Ihre gespeicherten personenbezogenen Daten, deren Herkunft und Empfänger und den Zweck der Datenverarbeitung und ggf. ein Recht auf Berichtigung, Sperrung oder Löschung dieser Daten. Hierzu sowie zu weiteren Fragen zum Thema personenbezogener Daten können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.</p><h3>Widerspruch gegen Werbe-Mails</h3><p>Der Nutzung von im Rahmen der Impressumspflicht veröffentlichten Kontaktdaten zur Übersendung von nicht ausdrücklich angeforderter Werbung und Informationsmaterialien wird hiermit widersprochen. Die Betreiber der Seiten behalten sich ausdrücklich rechtliche Schritte im Falle der unverlangten Zusendung von Werbeinformationen, etwa durch Spam-E-Mails, vor.</p><h2>3. Datenerfassung auf unserer Website</h2><h3>Cookies</h3><p>Die Internetseiten verwenden teilweise so genannte Cookies. Cookies richten auf Ihrem Rechner keinen Schaden an und enthalten keine Viren. Cookies dienen dazu, unser Angebot nutzerfreundlicher, effektiver und sicherer zu machen. Cookies sind kleine Textdateien, die auf Ihrem Rechner abgelegt werden und die Ihr Browser speichert.</p><p>Die meisten der von uns verwendeten Cookies sind so genannte „Session-Cookies“. Sie werden nach Ende Ihres Besuchs automatisch gelöscht. Andere Cookies bleiben auf Ihrem Endgerät gespeichert bis Sie diese löschen. Diese Cookies ermöglichen es uns Ihren Browser beim nächsten Besuch wiederzuerkennen.</p><p>Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die Annahme von Cookies für bestimmte Fälle oder generell ausschließen sowie das automatische Löschen der Cookies beim Schließen des Browsers aktivieren. Bei der Deaktivierung von Cookies kann die Funktionalität dieser Website eingeschränkt sein.</p><p>Cookies, die zur Durchführung des elektronischen Kommunikationsvorgangs oder zur Bereitstellung bestimmter, von Ihnen erwünschter Funktionen (z.B. Warenkorbfunktion) erforderlich sind, werden auf Grundlage von Art. 6 Abs. 1 lit. f DSGVO gespeichert. Der Webseitenbetreiber hat ein berechtigtes Interesse an der Speicherung von Cookies zur technisch fehlerfreien und optimierten Bereitstellung seiner Dienste. Soweit andere Cookies (z.B. Cookies zur Analyse Ihres Surfverhaltens) gespeichert werden, werden diese in dieser Datenschutzerklärung gesondert behandelt.</p><h3>Server-Log-Dateien</h3><p>Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt. Dies sind:</p><ul><li>Browsertyp und Browserversion</li><li>verwendetes Betriebssystem</li><li>Referrer URL</li><li>Hostname des zugreifenden Rechners</li><li>Uhrzeit der Serveranfrage</li><li>MAC- und IP-Adresse</li></ul><p>Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen.</p><p>Grundlage für die Datenverarbeitung ist Art. 6 Abs. 1 lit. f DSGVO, der die Verarbeitung von Daten zur Erfüllung eines Vertrags oder vorvertraglicher Maßnahmen gestattet.</p><h3>Kontaktformular</h3><p>Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.</p><p>Die Verarbeitung der in das Kontaktformular eingegebenen Daten erfolgt somit ausschließlich auf Grundlage Ihrer Einwilligung (Art. 6 Abs. 1 lit. a DSGVO). Sie können diese Einwilligung jederzeit widerrufen. Dazu reicht eine formlose Mitteilung per E-Mail an uns. Die Rechtmäßigkeit der bis zum Widerruf erfolgten Datenverarbeitungsvorgänge bleibt vom Widerruf unberührt.</p><p>Die von Ihnen im Kontaktformular eingegebenen Daten verbleiben bei uns, bis Sie uns zur Löschung auffordern, Ihre Einwilligung zur Speicherung widerrufen oder der Zweck für die Datenspeicherung entfällt (z.B. nach abgeschlossener Bearbeitung Ihrer Anfrage). Zwingende gesetzliche Bestimmungen – insbesondere Aufbewahrungsfristen – bleiben unberührt.</p><h3>Registrierung auf dieser Website</h3><p>Sie können sich auf unserer Website registrieren, um zusätzliche Funktionen auf der Seite zu nutzen. Die dazu eingegebenen Daten verwenden wir nur zum Zwecke der Nutzung des jeweiligen Angebotes oder Dienstes, für den Sie sich registriert haben. Die bei der Registrierung abgefragten Pflichtangaben müssen vollständig angegeben werden. Anderenfalls werden wir die Registrierung ablehnen. </p><p>Für wichtige Änderungen etwa beim Angebotsumfang oder bei technisch notwendigen Änderungen nutzen wir die bei der Registrierung angegebene E-Mail-Adresse, um Sie auf diesem Weg zu informieren.</p><p>Die Verarbeitung der bei der Registrierung eingegebenen Daten erfolgt auf Grundlage Ihrer Einwilligung (Art. 6 Abs. 1 lit. a DSGVO). Sie können eine von Ihnen erteilte Einwilligung jederzeit widerrufen. Dazu reicht eine formlose Mitteilung per E-Mail an uns. Die Rechtmäßigkeit der bereits erfolgten Datenverarbeitung bleibt vom Widerruf unberührt.</p><p>Die bei der Registrierung erfassten Daten werden von uns gespeichert, solange Sie auf unserer Website registriert sind und werden anschließend gelöscht. Gesetzliche Aufbewahrungsfristen bleiben unberührt.</p><h3>Verarbeiten von Daten (Kunden- und Vertragsdaten)</h3><p>Wir erheben, verarbeiten und nutzen personenbezogene Daten nur, soweit sie für die Begründung, inhaltliche Ausgestaltung oder Änderung des Rechtsverhältnisses erforderlich sind (Bestanddaten). Dies erfolgt auf Grundlage von Art. 6 Abs. 1 lit. b DSGVO, der die Verarbeitung von Daten zur Erfüllung eines Vertrags oder vorvertraglicher Maßnahmen gestattet. Personenbezogene Daten über die Inanspruchnahme unserer Internetseiten (Nutzungsdaten) erheben, verarbeiten und nutzen wir nur, soweit dies erforderlich ist, um dem Nutzer die Inanspruchnahme des Dienstes zu ermöglichen oder abzurechnen.</p><p>Die erhobenen Kundendaten werden nach Abschluss des Auftrags oder Beendigung der Geschäftsbeziehung gelöscht. Gesetzliche Aufbewahrungsfristen bleiben unberührt.</p><h3>Datenübermittlung bei Vertragsschluss für Dienstleistungen und digitale Inhalte</h3><p>Wir übermitteln personenbezogene Daten an Dritte nur dann, wenn dies im Rahmen der Vertragsabwicklung notwendig ist, etwa an das mit der Zahlungsabwicklung beauftragte Kreditinstitut.</p><p>Eine weitergehende Übermittlung der Daten erfolgt nicht bzw. nur dann, wenn Sie der Übermittlung ausdrücklich zugestimmt haben. Eine Weitergabe Ihrer Daten an Dritte ohne ausdrückliche Einwilligung, etwa zu Zwecken der Werbung, erfolgt nicht. </p><p>Grundlage für die Datenverarbeitung ist Art. 6 Abs. 1 lit. b DSGVO, der die Verarbeitung von Daten zur Erfüllung eines Vertrags oder vorvertraglicher Maßnahmen gestattet. </p><h2>4. Zahlungsanbieter</h2><h3>PayPal</h3><p>Auf unserer Website bieten wir u.a. die Bezahlung via PayPal an. Anbieter dieses Zahlungsdienstes ist die PayPal (Europe) S.à.r.l. et Cie, S.C.A., 22-24 Boulevard Royal, L-2449 Luxembourg (im Folgenden „PayPal“).</p><p>Wenn Sie die Bezahlung via PayPal auswählen, werden die von Ihnen eingegebenen Zahlungsdaten an PayPal übermittelt.</p><p>Die Übermittlung Ihrer Daten an PayPal erfolgt auf Grundlage von Art. 6 Abs. 1 lit. a DSGVO (Einwilligung) und Art. 6 Abs. 1 lit. b DSGVO (Verarbeitung zur Erfüllung eines Vertrags). Sie haben die Möglichkeit, Ihre Einwilligung zur Datenverarbeitung jederzeit zu widerrufen. Ein Widerruf wirkt sich auf die Wirksamkeit von in der Vergangenheit liegenden Datenverarbeitungsvorgängen nicht aus.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="m-footer">
        <div class="m-footer__inner">
            Hotspot bereitgestellt
            <br/>
            von NetCologne.
        </div>
    </div>
</div>
</body>
</html>