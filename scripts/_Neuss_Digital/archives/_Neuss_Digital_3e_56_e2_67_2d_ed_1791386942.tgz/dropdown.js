


    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
    <head>

    <meta name="robots" content="noindex,nofollow">

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/dropdown.js"></script>
    <script type="text/javascript" src="js/toggle.js"></script>
    <script type="text/javascript" src="js/jquery_modal.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <title>Hotspot Login</title>
    <!--<base href="https://www.hotsplots.de" />-->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    
    <noscript><link rel="stylesheet" type="text/css" href="css/noJS.css" /></noscript>
    <link rel="shortcut icon" href="https://www.hotsplots.de/favicon.ico" type="image/x-ico; charset=binary" />
    <link rel="icon" href="https://www.hotsplots.de/favicon.ico" type="image/x-ico; charset=binary" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style_selector.css" />
    <link rel="stylesheet" type="text/css" media="all" href="css/hotsplots1200-.css" />
    <link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 551px)" href="css/hotsplots500-1200.css" />
    <link rel="stylesheet" media="screen and (max-width: 550px)" href="css/hotsplots-550.css" />

    <style type="text/css">
    BODY {  margin: 0 0 0 0; background-color: ; }
    
    
    </style>
    </head>
    <body>
    <div class="login-header"><center><img title="stadtwerke neuss" style="padding:10px" class="scale-with-grid" src="../loginpages/BCMR0C0107810367_unten.jpg"></center></div>
    <div id="loginBox">
    <div id="container" class="cf">
    <div id="header" class="cf">
    
    </div><!-- close navLanguage -->

    <div class="login-wrap">
    <a href="http://www.hotsplots.de"><span id="logo_span"></span></a>
    <div id="dd" class="wrapper-dropdown-2">
      <span><img id="lang_flag" src="./images/flags/flags_iso/32/de.png" /><span class="lang_name" id="lang_name">Deutsch</span></span>
      <!--<span>Deutsch</span>-->
      <ul class="dropdown">

    <li><a href="?ll=de&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/de.png" alt="flag de" /><span class="lang_name">Deutsch</span></a></li><li><a href="?ll=en&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/en.png" alt="flag en" /><span class="lang_name">English</span></a></li><li><a href="?ll=es&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/es.png" alt="flag es" /><span class="lang_name">Español</span></a></li><li><a href="?ll=fr&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/fr.png" alt="flag fr" /><span class="lang_name">Français</span></a></li><li><a href="?ll=it&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/it.png" alt="flag it" /><span class="lang_name">Italiano</span></a></li><li><a href="?ll=nl&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/nl.png" alt="flag nl" /><span class="lang_name">Nederlands</span></a></li><li><a href="?ll=cz&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/cz.png" alt="flag cz" /><span class="lang_name">český</span></a></li><li><a href="?ll=pl&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/pl.png" alt="flag pl" /><span class="lang_name">Polski</span></a></li><li><a href="?ll=ro&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/ro.png" alt="flag ro" /><span class="lang_name">Română</span></a></li><li><a href="?ll=bg&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/bg.png" alt="flag bg" /><span class="lang_name">български</span></a></li><li><a href="?ll=ru&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/ru.png" alt="flag ru" /><span class="lang_name">русский</span></a></li><li><a href="?ll=tr&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/tr.png" alt="flag tr" /><span class="lang_name">Türkçe</span></a></li><li><a href="?ll=ua&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/ua.png" alt="flag ua" /><span class="lang_name">українська</span></a></li><li><a href="?ll=ar&res=notyet&uamip=192.168.44.1&uamport=80&challenge=3526de7b112d3bcdd7242529bc6fc8d7&called=20-97-27-80-4B-35&mac=DE-5E-D9-BB-47-7D&ip=192.168.44.22&nasid=SWN-Router-6006995248&sessionid=6ac664d900000002&userurl=http%3A%2F%2Fdetectportal.firefox.com%2Fjs%2Fdropdown.js"><img src="./images/flags/flags_iso/32/ar.png" alt="flag ar" /><span class="lang_name">عربي</span></a></li>
      </ul>
    </div>
    <h2>Stadtwerke Neuss</h2><!-- close loginHead -->
    <!-- close contentHeader -->
    <!-- close header-->

    <div id="contentWrap" class="cf">
    <div class="col2">
    
    <div>
    
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h1>Nutzungsbedingungen</h1>
        </div>
        <div class="modal-body">
          <h3>1 Gestattung des Internetzuganges</h3>

<p>Die hotsplots GmbH, Köpenicker Straße 154 A, 10997 Berlin, registriert beim Amtsgericht Berlin Charlottenburg unter HRB 93460B (nachfolgend: HOTSPLOTS) ermöglicht Endnutzern den öffentlichen Internetzugang an WLAN-Hotspots des Standortpartners . Der Endnutzer ist zur Nutzung des Internetzugangs berechtigt, wenn er diese Nutzungsbedingungen akzeptiert und sich im Fall des Ticket-Login oder User-Login mit gültigen Zugangsdaten eingeloggt hat. Es besteht kein Anspruch auf Nutzung des Internetzugangs. </p>

<h3>2 Verfügbarkeit</h3>

<p>Es besteht keine Garantie für die Verfügbarkeit von Hotspots an
bestimmten Standorten und keine Verpflichtung, einmal eingerichtete Hotspots
dauerhaft verfügbar zu halten. HOTSPLOTS weist ausdrücklich darauf hin, dass
es im Ermessen des Standortpartners liegt, Hotspots bereitzustellen oder
außer Betrieb zu nehmen. Es wird keine Verfügbarkeit bestimmter Inhalte an
bestimmten Hotspots garantiert. HOTSPLOTS weist ausdrücklich darauf hin,
dass Standortpartner die Möglichkeit haben, an einzelnen Hotspots
Jugendschutzmaßnahmen zu ergreifen und den Zugriff auf Inhalte zu
filtern. Für die Nutzung des WLAN ist ein zu IEEE 802.11n kompatibles
Endgerät erforderlich. Es werden weder Mindestbandbreite noch
Störungsfreiheit garantiert.  </p>

<h3>3 Verantwortung, Gefahren</h3>

<p>HOTSPLOTS und / oder der Standortpartner sind nicht für Inhalte
verantwortlich, die von dem Endnutzer oder Dritten über den Hotspot
abgerufen, in das Internet eingestellt oder in irgendeiner Weise verbreitet
werden. Die übertragenen Inhalte unterliegen keiner Überprüfung durch
HOTSPLOTS und / oder den Standortpartner. Die Nutzung des Internetzugangs
erfolgt auf eigene Gefahr und auf Risiko des Endnutzers. Die
Datenübertragung erfolgt ohne Verschlüsselung. Bei Bedarf muss der Endnutzer
eigene Maßnahmen zur Sicherung seines Datenverkehrs ergreifen. </p>

<h3>4 Pflichten der Endnutzer</h3>

<p>Der Endnutzer darf die Hotspots nur bestimmungsgemäß und nach Maßgabe der
in der Bundesrepublik Deutschland geltenden Gesetze und Verordnungen
benutzen. Der Endnutzer ist verpflichtet, die von HOTSPLOTS und / oder dem
Standortpartner angebotenen Telekommunikationsdienstleistungen nicht zu
Zwecken zu missbrauchen, die den gesetzlichen Bestimmungen oder diesen
Endnutzerbedingungen widersprechen, insbesondere ist der unaufgeforderte
Versand von Nachrichten oder Informationen an Dritte zu Werbezwecken
(Spamming) zu unterlassen. Der Endnutzer hat es zu unterlassen, bei der
Nutzung eines Hotspots Straftaten zu begehen und / oder vorzubereiten,
insbesondere Informationen zu verbreiten, die gem. §§ 130, 130a und 131 StGB
der Volksverhetzung dienen, und / oder die im Sinne des § 184 StGB
pornografisch sind, und / oder die geeignet sind, Kinder oder Jugendliche
sittlich schwer zu gefährden und / oder in ihrem Wohl zu
beeinträchtigen. Darüber hinaus hat er es zu unterlassen, zu Straftaten
anzuleiten oder Gewalt zu verherrlichen oder zu verharmlosen. Der Endnutzer
hat alle erforderlichen und üblichen Sicherungsmaßnahmen gegen die
ungewollte und missbräuchliche Nutzung der Hotspots über die von ihm
eingesetzten IT-Systeme durch unbefugte Dritte zu treffen. Soweit der
Endnutzer eine ungewollte oder missbräuchliche Nutzung eines Hotspots über
ein von ihm eingesetztes IT-System feststellt, hat er HOTSPLOTS und / oder
den Standortpartner unverzüglich zu unterrichten.  </p>

<h3>5 Datenschutz und Datensicherheit</h3>

<p>Die einschlägigen datenschutzrechtlichen Vorschriften des TKG und der DSGVO werden eingehalten. Verkehrsdaten werden von HOTSPLOTS nach den
gesetzlichen Vorgaben des TKG erhoben, verarbeitet und gespeichert. Dies
umfasst die IP-Adresse und die MAC-Adresse des Endgerätes sowie Nutzungszeit
und -dauer. Darüber hinaus behalten sich HOTSPLOTS und der Standortpartner
vor, Daten zu statistischen Zwecken auszuwerten. Die Fristen
des TKG zum Löschen von Daten werden von HOTSPLOTS eingehalten.  Der
Datenschutzbeauftragte von HOTSPLOTS ist per E-Mail unter
datenschutz@hotsplots.de erreichbar; oder postalisch unter: </p>

<p>
hotsplots GmbH<br>
Datenschutzbeauftragter<br> 
Köpenicker Straße 154 A<br> 
10997 Berlin <br>
Deutschland
</p>

<h3>6 Sonstiges</h3>

<p>HOTSPLOTS behält sich das Recht vor, diese Nutzungsbedingungen in Zukunft
zu aktualisieren. Mit jeder Nutzung des Internetzugangs erklärt sich der
Nutzer mit der jeweils gültigen Fassung dieser Nutzungsbedingungen
einverstanden.  </p>

<h3>7 Schlussbestimmungen</h3>

<p>Es gilt das Recht der Bundesrepublik Deutschland. Hat der Nutzer den Vertrag als Verbraucher geschlossen, sind darüber hinaus die zwingenden Verbraucherschutzbestimmungen anwendbar, die in dem Staat gelten, in dem sich der Nutzer während der Hotspot Nutzung aufhält, sofern diese dem Nutzer einen weitergehenden Schutz gewähren.
Im Streitfall steht dem Nutzer das Recht zu, ein Schlichtungsverfahren einzuleiten. Hierfür muss der Nutzer einen entsprechenden Antrag bei der zuständigen Behörde stellen. </p>


<p>Berlin, 01.08.2025 </p>

        </div>
      </div>
    </div>
  </div>

    <div class="area">
    <form method="post" action="/auth/login.php">
      <div><h3>Gratis WLAN</h3><p class="alert_error" id="notAccepted" style="display:none;">Bitte akzeptieren Sie die Nutzungsbedingungen.</p>
        <input type="hidden" name="haveTerms" value="1"><input type="hidden" name="termsOK" value="1"/>
        <label style="margin-left:0px;" id="labelCheck" for="checkAGB">Ich akzeptiere die <a href="" data-toggle="modal" data-target="#myModal">Nutzungsbedingungen</a> von HOTSPLOTS</label>  <p>Pro Kalendertag und Nutzer stehen Ihnen 100&nbsp;MB zur Verfügung.</p> 
        <div class="formRowSubmit">
          <input type="submit" id="tFreeloginBtn" name="button" value="kostenlos einloggen" class="submit" />
        
        </div><!-- close formRow forActions cf -->
      </div>



      <div id="terms" style="display: none">
      <h3>1 Gestattung des Internetzuganges</h3>

<p>Die hotsplots GmbH, Köpenicker Straße 154 A, 10997 Berlin, registriert beim Amtsgericht Berlin Charlottenburg unter HRB 93460B (nachfolgend: HOTSPLOTS) ermöglicht Endnutzern den öffentlichen Internetzugang an WLAN-Hotspots des Standortpartners . Der Endnutzer ist zur Nutzung des Internetzugangs berechtigt, wenn er diese Nutzungsbedingungen akzeptiert und sich im Fall des Ticket-Login oder User-Login mit gültigen Zugangsdaten eingeloggt hat. Es besteht kein Anspruch auf Nutzung des Internetzugangs. </p>

<h3>2 Verfügbarkeit</h3>

<p>Es besteht keine Garantie für die Verfügbarkeit von Hotspots an
bestimmten Standorten und keine Verpflichtung, einmal eingerichtete Hotspots
dauerhaft verfügbar zu halten. HOTSPLOTS weist ausdrücklich darauf hin, dass
es im Ermessen des Standortpartners liegt, Hotspots bereitzustellen oder
außer Betrieb zu nehmen. Es wird keine Verfügbarkeit bestimmter Inhalte an
bestimmten Hotspots garantiert. HOTSPLOTS weist ausdrücklich darauf hin,
dass Standortpartner die Möglichkeit haben, an einzelnen Hotspots
Jugendschutzmaßnahmen zu ergreifen und den Zugriff auf Inhalte zu
filtern. Für die Nutzung des WLAN ist ein zu IEEE 802.11n kompatibles
Endgerät erforderlich. Es werden weder Mindestbandbreite noch
Störungsfreiheit garantiert.  </p>

<h3>3 Verantwortung, Gefahren</h3>

<p>HOTSPLOTS und / oder der Standortpartner sind nicht für Inhalte
verantwortlich, die von dem Endnutzer oder Dritten über den Hotspot
abgerufen, in das Internet eingestellt oder in irgendeiner Weise verbreitet
werden. Die übertragenen Inhalte unterliegen keiner Überprüfung durch
HOTSPLOTS und / oder den Standortpartner. Die Nutzung des Internetzugangs
erfolgt auf eigene Gefahr und auf Risiko des Endnutzers. Die
Datenübertragung erfolgt ohne Verschlüsselung. Bei Bedarf muss der Endnutzer
eigene Maßnahmen zur Sicherung seines Datenverkehrs ergreifen. </p>

<h3>4 Pflichten der Endnutzer</h3>

<p>Der Endnutzer darf die Hotspots nur bestimmungsgemäß und nach Maßgabe der
in der Bundesrepublik Deutschland geltenden Gesetze und Verordnungen
benutzen. Der Endnutzer ist verpflichtet, die von HOTSPLOTS und / oder dem
Standortpartner angebotenen Telekommunikationsdienstleistungen nicht zu
Zwecken zu missbrauchen, die den gesetzlichen Bestimmungen oder diesen
Endnutzerbedingungen widersprechen, insbesondere ist der unaufgeforderte
Versand von Nachrichten oder Informationen an Dritte zu Werbezwecken
(Spamming) zu unterlassen. Der Endnutzer hat es zu unterlassen, bei der
Nutzung eines Hotspots Straftaten zu begehen und / oder vorzubereiten,
insbesondere Informationen zu verbreiten, die gem. §§ 130, 130a und 131 StGB
der Volksverhetzung dienen, und / oder die im Sinne des § 184 StGB
pornografisch sind, und / oder die geeignet sind, Kinder oder Jugendliche
sittlich schwer zu gefährden und / oder in ihrem Wohl zu
beeinträchtigen. Darüber hinaus hat er es zu unterlassen, zu Straftaten
anzuleiten oder Gewalt zu verherrlichen oder zu verharmlosen. Der Endnutzer
hat alle erforderlichen und üblichen Sicherungsmaßnahmen gegen die
ungewollte und missbräuchliche Nutzung der Hotspots über die von ihm
eingesetzten IT-Systeme durch unbefugte Dritte zu treffen. Soweit der
Endnutzer eine ungewollte oder missbräuchliche Nutzung eines Hotspots über
ein von ihm eingesetztes IT-System feststellt, hat er HOTSPLOTS und / oder
den Standortpartner unverzüglich zu unterrichten.  </p>

<h3>5 Datenschutz und Datensicherheit</h3>

<p>Die einschlägigen datenschutzrechtlichen Vorschriften des TKG und der DSGVO werden eingehalten. Verkehrsdaten werden von HOTSPLOTS nach den
gesetzlichen Vorgaben des TKG erhoben, verarbeitet und gespeichert. Dies
umfasst die IP-Adresse und die MAC-Adresse des Endgerätes sowie Nutzungszeit
und -dauer. Darüber hinaus behalten sich HOTSPLOTS und der Standortpartner
vor, Daten zu statistischen Zwecken auszuwerten. Die Fristen
des TKG zum Löschen von Daten werden von HOTSPLOTS eingehalten.  Der
Datenschutzbeauftragte von HOTSPLOTS ist per E-Mail unter
datenschutz@hotsplots.de erreichbar; oder postalisch unter: </p>

<p>
hotsplots GmbH<br>
Datenschutzbeauftragter<br> 
Köpenicker Straße 154 A<br> 
10997 Berlin <br>
Deutschland
</p>

<h3>6 Sonstiges</h3>

<p>HOTSPLOTS behält sich das Recht vor, diese Nutzungsbedingungen in Zukunft
zu aktualisieren. Mit jeder Nutzung des Internetzugangs erklärt sich der
Nutzer mit der jeweils gültigen Fassung dieser Nutzungsbedingungen
einverstanden.  </p>

<h3>7 Schlussbestimmungen</h3>

<p>Es gilt das Recht der Bundesrepublik Deutschland. Hat der Nutzer den Vertrag als Verbraucher geschlossen, sind darüber hinaus die zwingenden Verbraucherschutzbestimmungen anwendbar, die in dem Staat gelten, in dem sich der Nutzer während der Hotspot Nutzung aufhält, sofern diese dem Nutzer einen weitergehenden Schutz gewähren.
Im Streitfall steht dem Nutzer das Recht zu, ein Schlichtungsverfahren einzuleiten. Hierfür muss der Nutzer einen entsprechenden Antrag bei der zuständigen Behörde stellen. </p>


<p>Berlin, 01.08.2025 </p>

      </div>

      <input type="hidden" name="challenge" value="3526de7b112d3bcdd7242529bc6fc8d7" />
      <input type="hidden" name="uamip" value="192.168.44.1" />
      <input type="hidden" name="uamport" value="80" />
      <input type="hidden" name="userurl" value="http://detectportal.firefox.com/js/dropdown.js" />
      <input type="hidden" name="myLogin" value="agb" />
      <input type="hidden" name="ll" value="de" />
      <input type="hidden" name="nasid" value="SWN-Router-6006995248" />
      <input type="hidden" name="custom" value="1" />
   </form>

    </div><!--area-->
    <div id="pricing_span"></div><!-- close pricing --><p class="hint">An diesem Hotspot ist ein Jugendschutzfilter aktiviert. Einige Websites sind daher nicht erreichbar.</p>
    <div id="navFooter2">
    <div class="cf">
    <a href="https://www.hotsplots.com/impressum/" title="Impressum">Impressum</a><a href="https://www.hotsplots.com/datenschutz/datenschutz-hotspot/" title="Datenschutz">Datenschutz</a>
    </div>
    </div><!-- close navFooter -->
    
    </div><!-- close content -->
    </div><!-- close col2 -->
    
    <div class="col1">
    <div id="navFooter">
    <ul class="cf">
    
    </ul>
    </div><!-- close navMain -->
    </div><!-- close col1 -->
    
    </div><!-- close contentWrap -->
    </div><!-- close container -->
    </div><!-- close loginBox --><div id="bothtml"><style rel="stylesheet">

@media only screen and (max-device-width: 720px) {
#labelCheck {font-size: 90%; margin-left: 3px;letter-spacing:-0.4px}
}

html .login-wrap {max-width:500px;width: 94%;height:auto}

.wrapper-dropdown-2 .lang_name  {padding: 0 0 0 5px;}
.wrapper-dropdown-2.active .dropdown img {padding: 0}
.wrapper-dropdown-2 a:link {color:white;text-decoration:none}

#loginBox {margin-top:10px;margin-bottom: 0px;}
img.scale-with-grid {max-width: 95%;height: auto;}
body {height:100%;background-color: #fff;background-image: url()}
html .login-header {height:auto}
.hint {font-size:12px;letter-spacing:-0.4px}
html .formRowSubmit input[type="submit"] {font-size: 18px;}
</style>
</div>
    </div>

    </body>
    </html>
    