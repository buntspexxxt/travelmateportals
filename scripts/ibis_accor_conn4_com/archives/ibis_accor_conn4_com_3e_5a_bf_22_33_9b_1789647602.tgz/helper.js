


<!DOCTYPE html>
<!--[if IEMobile 7 ]><html  class="no-js iem7"><![endif]-->
<!--[if lt IE 7 ]><html  class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7 ]><html  class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8 ]><html  class="no-js lt-ie9"><![endif]-->
<!--[if IE 9 ]><html  class="no-js lt-ie10"><![endif]-->
<!--[if (gte IE 10)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!-->
<html  class="no-js">
<!--<![endif]-->




<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <title>The Cloud, WiFi Broadband</title>
    <meta name="description"
          content="Wi-Fi Broadband for the mobile, iPhone, iPad, Android and other handheld devices."/>
    <meta name="keywords" content="Wi-Fi, wifi, mobile, iPhone, iPad, Android, handheld, FastConnect"/>
    <meta name="format-detection" content="telephone=no"/>

    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimal-ui">
    <meta http-equiv="cleartype" content="on">

    <!--[if lt IE 9]>
    <script language="javascript" type="text/javascript" src='/service-platform/js/vendor/html5.js'>
        //html5.js  html5shim.googlecode.com
    </script>
    <![endif]-->

    

    <!-- For iPhone 4 with high-resolution Retina display: -->
    <link rel="apple-touch-icon-precomposed" sizes="114x114"
          href='/service-platform/images/favicons/h/apple-touch-icon.png'/>
    <!-- For first-generation iPad: -->
    <link rel="apple-touch-icon-precomposed" sizes="72x72"
          href='/service-platform/images/favicons/m/apple-touch-icon.png'/>
    <!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
    <link rel="apple-touch-icon-precomposed"
          href='/service-platform/images/favicons/l/apple-touch-icon-precomposed.png'/>
    <!-- For Nokia -->
    <link rel="shortcut icon" href='/service-platform/images/favicons/l/apple-touch-icon.png'/>
    <!-- For everything else -->
    <link rel="shortcut icon" href='/service-platform/images/favicons/favicon.ico'/>

    <!-- Tile icon for Win8 (114x114 + tile color) -->
    <meta name="msapplication-TileImage" content='/service-platform/images/favicons/h/apple-touch-icon.png'>
    <meta name="msapplication-TileColor" content="#222222">

    <link rel="stylesheet" href='/service-platform/css/layout.css'>
    <link rel="stylesheet" href='/service-platform/css/video-js.min.css'>
    <link rel="stylesheet" href='/service-platform/css/videojs-overlay.css'>
    <link rel="stylesheet" href='/service-platform/css/videojs.vast.vpaid.css'>

    
        <!--This tag is used to load branding css depending on page -->
        <link rel="stylesheet" href='/service-platform/branding/venue.css'>
    
    <!-- The IE conditional comments need to be within CDATA otherwise the JSPX does not emit them -->
    <!--[if (lt IE 9) & (!IEMobile)]>
    <script src='/service-platform/js/vendor/selectivizr-1.0.3b.min.js'>
        // selectivizr.js (css3 selectors for IE6-8)
    </script>
    <![endif]-->
    <!-- Modernizr provides CSS selectors for browser features -->
    <script src='/service-platform/js/vendor/modernizr-2.6.2.min.js'>
        //modernizr.js
    </script>

    <script src='/service-platform/js/vendor/jquery-3.6.0.min.js' type="text/javascript">
        //jquery.js
    </script>

    
    
        
    
    

</head>


<body class="clearfix">
<div id="wrapper">
    



    



    


<header class="ir the-cloud">
    <a class="venuelogo ir irleft" href='#'>&nbsp;</a>
    <a class="ir" href='#'>&nbsp;</a>
</header>

    <section>
        <h2><a href='/service-platform/home'><div class="font-icon">&#xe800;</div></a>&nbsp;<!--oneclick_login_title--></h2>
        <form id="registration" method="POST" action="/service-platform/macauthlogin/v1/registration" novalidate="novalidate">
            <p class="information">&nbsp;<!--oneclick_login_info--></p>
            
            <fieldset>
                
                <div class="input-item terms">
                    <input id="terms" name="terms" value="true" type="checkbox" >
                    <label for="terms">
                        
                            
                            
                        I have read and agree to the <a href="/service-platform/legal/terms">Terms &amp; Conditions</a><br> and <a href="/service-platform/legal/privacy">Privacy &amp; Cookies notice</a><!--login_create_account_terms_label--><span>*</span>
                    </label>
                </div>
                <p></p>
                <div class="buttons"><button id="btnSubmit" class="submit" type="submit">Continue<!--button_continue--></button></div>
            </fieldset>
        </form>
        
    </section>
    




<div class="modal">
    <div class="modalHeader" id="modalHeader">
        <a class="btn-close" id="btn-close"></a>
    </div>
    <div style="width: 100%; height: 100%">
        <iframe id="iframecontent" scrolling="auto"></iframe>
    </div>
</div>

<footer>
    
        
        
            <nav>
                <div class="footer-links">
                    <a class="terms" href='/service-platform/legal/terms' target="_blank">Terms<!--footer_link_terms--></a>
                    <a class="terms" href='/service-platform/legal/privacy' target="_blank">Privacy & Cookies<!--footer_link_privacy--></a>
                    <a class="terms" href='/service-platform/legal/about' target="_blank">Imprint<!--footer_link_aboutus--></a>
                </div>
            </nav>
        
    
   
    <aside>
        <p>The WiFi network is operated and made available by The Cloud Networks Germany GmbH. The use of the WiFi as well as the available service or contents are subject to the user terms and conditions of The Cloud as well as the user terms and conditions of the respective service or content provider. The site owner does not assume liability for the operation and the availability of the WiFi network or the associated services or content insofar he does not provide these himself.<!--footer_aside--></p>
        <small>&copy;&nbsp;2026&nbsp;The Cloud Networks Germany GmbH - 
            <div class="venue">
                
                    
                        2050683
                    
                    
                

            </div>
        </small>
        <!--
        10.4.0.30
        -->
    </aside>
</footer>

<script type="text/javascript">

    var showContent = function(url){
        $("#iframecontent")
            .attr({"scrolling": "auto", "src": url})
            .load(function() {
                $(this).css("height", $(this).contents().height() + "px");
            });
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        $('.modal').show();

    };

    $(window).on('load', function () {
        $(".trigger_modal_terms").click(function(){
            showContent('/service-platform/legal/terms');
        });

        $(".trigger_modal_privacy").click(function(){
            showContent('/service-platform/legal/privacy');
        });

        $(".trigger_modal_about").click(function(){
            showContent('/service-platform/legal/about');
        });

        $('.btn-close').click(function(){
            $('.modal').hide();
        });

    });
</script>

</div>


<!-- Add your site or application content here -->
<!-- JavaScript at the bottom for fast page loading -->
<script src='/service-platform/js/vendor/zepto.min.js' type="text/javascript">
    //zepto.min.js
</script>
<script src='/service-platform/js/helper.js' type="text/javascript">
    //helper.js
</script>
<script src='/service-platform/js/plugins.js' type="text/javascript">
    //plugins.js
</script>
<script src='/service-platform/js/vendor/jquery.corner-2.13.js' type="text/javascript">
    //jquery.corner.js
</script>
<script src='/service-platform/js/vendor/jquery.placeholder-2.0.7.js' type="text/javascript">
    //jquery.placeholder.js
</script>

<!-- The IE conditional comments need to be within CDATA otherwise the JSPX does not emit them -->
<!--[if (lt IE 9) & (!IEMobile)]>
<script src='/service-platform/js/vendor/imgSizer-20130717.js' type="text/javascript">
    // imgSizer.js (fluid images for IE)
</script>
<script type="text/javascript">
    imgSizer.Config.spacer = '/service-platform/images/spacer.gif';
    $(function () {
        // IE lt 9 specific startup code
        $('.submit').corner("6px");
    });
</script>
<![endif]-->
<!--[if IE 9 ]>
<script src='/service-platform/js/vendor/jquery.ie9gradius.js' type="text/javascript">
    // jquery.ie9gradius.js (fix for IE 9 gradient and border radius conflict)
</script>
<![endif]-->

<script type="text/javascript">
    $(function () {
        $("#registration").submit(function (e) {
            $("#btnSubmit").attr("disabled", true);
            return true;
        });
    });
</script>
</body>
</html>
