<!DOCTYPE html>
<html lang="en_US">
<head>
    <meta charset="UTF-8" />
    <title>Cookies are required</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Cookies are required</h1>

    <p>You must have HTTP cookies enabled to connect to the Wi-Fi hotspot.</p>

    <p>When you have enabled cookies in your browser click <a href="/wbs/authenticate-me/?redirectUrl=https%3A%2F%2F469.rdr.conn4.com%2Fadmon-assets%2Fident.php%3Fclient_mac%3D%7Bmac%7D%26client_ip%3D%7Bip%7D%26site_id%3D%7Bsite%7D%26signature%3D%7Bsignature%7D&signature=93ec9e5f4ac11ed2655bcbdff7f158e40c0e41f3408dffeaabd8197c6564b73b">reconnect</a> to proceed.</p>

    </body>
</html>