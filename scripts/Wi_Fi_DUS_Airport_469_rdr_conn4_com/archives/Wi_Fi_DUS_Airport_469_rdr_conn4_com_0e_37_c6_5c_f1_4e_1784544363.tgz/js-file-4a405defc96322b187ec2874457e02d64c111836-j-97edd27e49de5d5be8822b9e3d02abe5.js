<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" id="no-js">
    <head>
        <script>
            var scenename = 'sceneplayer';
            if (typeof scenename === 'undefined') {
  var scenename = 'undefined';
}

function logError(error) {
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "/admon-assets/log.php?channel=clienterror", true);
  oReq.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  oReq.send("type=" + error.type
    + "&msg=" + error.message
    + " | module=" + scenename
    + " | file=" + error.filename
    + " | line=" + error.lineno
    + " | col=" + error.colno
  );
}

window.addEventListener('error', logError);
        </script>

        <script type="text/javascript">with(document.documentElement){id=id.replace('no-','');}</script>
        <style>body{margin:0}object{position:absolute;top:0;left:0;opacity:0;z-index:100}.fullscreen{width:100%;height:100%;position:absolute;border:0}.fade-out{opacity:0}.fade-in{opacity:1;-webkit-transition:opacity 1500ms ease-out;-moz-transition:opacity 1500ms ease-out;-o-transition:opacity 1500ms ease-out;transition:opacity 1500ms ease-out}.message{background:rgba(0,0,0,.8);position:absolute;bottom:0;left:0;right:0;z-index:1000 !important;padding:1em;text-align:center;font-size:32px;color:#fff}.hidden,#no-js #_loading_indicator,#_scene_volume,#_standby_overlay{display:none}.error{background-color:#eee;z-index:200}.error>div{width:500px;text-align:center;margin:-5em auto 0;position:relative;top:50%;font-size:24px;font-family:Helvetica,Arial,sans-serif}#_scene_content>iframe.ios-fix{width:1px;min-width:100%;*width:100%;overflow:auto;height:100%;overflow-y:scroll;-webkit-overflow-scrolling:touch}#_loading_indicator{position:fixed;z-index:10000;bottom:0;top:0;left:0;right:0}#_loading_indicator>.loading--simple{position:absolute;bottom:.6rem;right:.8rem;font-size:.9rem;padding:.5rem;border-radius:.3rem;font-family:sans-serif;color:black;background-color:rgba(255,255,255,.9)}
</style>

            <style id="_scene_custom_style" type="text/css"></style>

        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        
            </head>

    <body>
        <!--
        <?xml version="1.0" encoding="UTF-8"?>
        <WISPAccessGatewayParam xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.acmewisp.com/WISPAccessGatewayParam.xsd">
            <Redirect>
                <AccessProcedure>1.0</AccessProcedure>
                <AccessLocation>12</AccessLocation>
                <LocationName>CONN4</LocationName>
                <LoginURL>https://469.rdr.conn4.com/wbs/de/roaming/return/</LoginURL>
                <MessageType>100</MessageType>
                <ResponseCode>0</ResponseCode>
            </Redirect>
        </WISPAccessGatewayParam>
    -->

        <noscript>
            <div class="error fullscreen">
                <div>
                    <p>Please enable JavaScript to continue.</p>
                </div>
            </div>
        </noscript>

        <div id="_error" class="error hidden fullscreen">
            <div>
                <h1>Error <span class="js-error-code">601</span></h1>
                <p>Need assistance?</p>
                <p>Wi-Fi-Hotline: +49 (0) 241 / 705 39 605<br/>
                <span style="font-size: 50%">(at local tariff throughout Germany)</span></p>
            </div>
        </div>
        
        
        
        
    <div id="_scene_content" data-channel="">
    </div>

        <div id="_loading_indicator" class="loading--initial">
            <div class="loading--simple">
                Loading ...
            </div>
                    </div>

        
        <script src="/cache/js-file-4a405defc96322b187ec2874457e02d64c111836-j-97edd27e49de5d5be8822b9e3d02abe5.js" type="text/javascript"></script>
                        <script type="text/javascript">
            (function() {
                if (!location.search) {
                    return;
                }

                var url = location.href.replace(location.search, '');
                if (history && history.replaceState) {
                    history.replaceState(history.state || {}, document.title, url);
                } else {
                    location.href = url;
                }
            })();
        </script>

        
        <script type="text/javascript">
            conn4.deviceConfiguration = false;

                                        conn4.log = $.noop;
            
//            conn4.recorder = new conn4.LogRecorder({log: conn4.log});
//            conn4.record = conn4.recorder.record;
            conn4.record = function() {};

                            conn4.eventTracker = new conn4.EventTracker({
                    logger: conn4.logger
                });
                conn4.trackEvent = conn4.eventTracker.track;
                        
            conn4.serverdate = new conn4.ServerDate({
                initializationTs: 1784542054730,
                log: conn4.log
            });
            var ServerDate = function () {
                return new Date(ServerDate.now());
            };
            ServerDate.now = function() {
                return conn4.serverdate.getMilliseconds();
            };

            
            
            conn4.hotspot = conn4.hotspot || {};
            conn4.hotspot.wbsToken = {"token":"SFdBKk86MzU6Ik0zXEhpbWFsYXlhXFNoYXJlZFxXQlNBcGlBdXRoXFRva2VuIjo2OntzOjk6IgAqAHNpdGVJZCI7aTo0Njk7czoxNjoiACoAcmVtb3RlQWRkcmVzcyI7czoxMjoiMTAuMjcuOTAuMjMxIjtzOjEzOiIAKgBtYWNBZGRyZXNzIjtzOjEyOiIwRTM3QzY1Q0YxNEUiO3M6MTE6IgAqAGRldmljZUlkIjtOO3M6MTA6IgAqAGNyZWF0ZWQiO086ODoiRGF0ZVRpbWUiOjM6e3M6NDoiZGF0ZSI7czoyNjoiMjAyNi0wNy0yMCAxMDowNzozNC4wMDAwMDAiO3M6MTM6InRpbWV6b25lX3R5cGUiO2k6MztzOjg6InRpbWV6b25lIjtzOjM6IlVUQyI7fXM6OToiACoAb3JpZ2luIjtzOjI1OiJodHRwczovLzQ2OS5yZHIuY29ubjQuY29tIjt9fDUzYmZmMjlkMTc1NDBlOTgyNDE0Y2M3NGJiMjdiNTg1NGYzYzcwM2IwYzRhNTQzNWU5YjhhYTY3ODUwNzY1MDE=","urls":{"grant_url":null,"continue_url":null}};
            setTimeout(function() {
                conn4.hotspot.wbsToken = undefined;
            }, 118 * 60 * 1000); 
            $(_.partial(conn4.startSceneLoader, {
                log: conn4.log,
                trackEvent: conn4.trackEvent,
                settings: {"sceneLoaderAssertLoaded":true,"sceneLoaderTimeoutLimit":2}
,
                schedule: {"token":{"site":469,"group":"desktop","mac":"0E37C65CF14E"},"site_title":"","url_version":1,"scene_template":"https:\/\/469.rdr.conn4.com\/scenes\/{id}\/","fallback":"https:\/\/469.rdr.conn4.com\/admon-assets\/fallback.html","error_404":"https:\/\/469.rdr.conn4.com\/admon\/404","initialization_ts":1784542054,"events":[{"time":"1984-11-17 00:00:00","seq":200,"type":"campaign","payload":null},{"time":"1984-11-17 00:00:00","seq":100,"type":"view","payload":{"type":"scene","data":{"id":"agbRwik_7LwIN_lF","module":"html-page-scene-wbs-new","variant":"default"}}}],"playlists":[],"navigations":[]}
            }));
        </script>
    
    <script>
        window.onmessage = function(e) {
            var prefix = 'navigate-top:';
            if (typeof e.data !== 'string') {
                return;
            }
            if (e.data.indexOf(prefix) !== 0) {
                return;
            }
            var url = e.data.slice(prefix.length);
            var link = document.createElement('a');
            link.href = url;
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
        }
    </script>
    </body>
</html>
