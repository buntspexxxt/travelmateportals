



<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>InControl 2</title>
<style>
body { background-color: rgba(255, 255, 255, 1); }
.maintain_bar { top: 20%; left: 0; right: 0; bottom:0; width: 100%; text-align: center; position: absolute; }
.maintain_board { text-align: left; vertical-align: middle; margin: 0 auto; width: 50%; height: 80px; font-size: 20px; font-family: 'Droid Sans', Helvetica, Arial, sans-serif; color: #333; background: rgba(255, 255, 255, 1); padding: 20px; border: 5px solid rgb(184, 184, 184); }
.header {font-size: 18px; font-weight: bold; color: #ff0000;}
.text {font-size: 14px; font-weight: bold; color: #000000;}
.error {font-size: 12px; color: #ff0000; display: block;}
.button {font-size: 14px; font-weight: bold; color: #000000; border: solid 1px #000099;}
</style>
<script language='javascript'>
</script>
<style>
</style>
</head>
<body>
	<div class="maintain_bar">
	<div class="maintain_board">
	
		<span class='header'>The page you are looking for does not exist.</span><br/><br/>
		<span class='text'>
			You may have mistyped the address or the page may have moved.
		</span>
	
	</div>
	</div>
</body>
</html>