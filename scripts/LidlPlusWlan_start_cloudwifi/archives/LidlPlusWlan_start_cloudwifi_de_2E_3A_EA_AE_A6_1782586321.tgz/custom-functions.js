$(document).ready(function(){
	/* Prevent double sending of Form */
	$('#login-form').on('submit', function(e){
        e.preventDefault();
		$("#btn-login").prop("disabled",true);
		console.log("Submitting...");
    });
	/* Moodal */
	$(".imprint").modaal({
		content_source: '#imprint',
		background: '#fff'
	});
	$(".privacy").modaal({
		content_source: '#privacy',
		background: '#fff'
	});
	$('.close').click(function(){
		$('.modaal-inner-wrapper').trigger('click');
	});
});