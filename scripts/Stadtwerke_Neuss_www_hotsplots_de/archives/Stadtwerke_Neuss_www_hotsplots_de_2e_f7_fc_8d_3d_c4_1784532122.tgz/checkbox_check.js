function checkCheckBox(theForm) {
    if (theForm.termsOK.checked == false) {
        document.getElementById('notAccepted').style.display = "block";
        return false;
    } else {
        return true;
    }
}

