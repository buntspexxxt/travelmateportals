/**
 * Created by ismail on 03.07.15.
 */
function toggle() {
    var ele = document.getElementById("terms");
    var text = document.getElementById("displayText");
    if(ele.style.display == "block") {
        ele.style.display = "none";
    }
    else {
        ele.style.display = "block";
    }
}